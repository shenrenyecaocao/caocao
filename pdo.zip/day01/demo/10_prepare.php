<?php 
//3、应用准备语句，更新cms_user表里的一条数据。观察返回。
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
//PDO通知mysql编译sql语句
/*
 * 4、应用准备语句，更新cms_user表里的一条数据，
 * 将更新条件设为参数，应用参数绑定指定要更新的记录的id值。
 * 观察更新后的结果。
 */
$query = "insert into cms_user
		  (username,password)
		  value
		  (?,?)";
$statm = $pdo->prepare($query);
//参数绑定
$username = "tom";
$statm->bindParam(1,$username);
$password = "123";
$statm->bindParam(2,$password);
//PDO通知mysql执行sql语句
$result = $statm->execute();
var_dump($result);



















































