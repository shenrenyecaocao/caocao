<?php 
//3、应用准备语句，更新cms_user表里的一条数据。观察返回。
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
//PDO通知mysql编译sql语句
$query = "update cms_user set username='jerry' 
		 where id=66";
$statm = $pdo->prepare($query);
//PDOStatement 通知mysql执行sql语句
$result = $statm->execute();
var_dump($result);










