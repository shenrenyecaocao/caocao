<?php 
header("Content-Type:text/html;charset=utf-8");
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
$query = "insert into cms_user
		  (username,password)
		  value
		  (:username,:password) ";
$statm = $pdo->prepare($query);
//绑定参数
$username = "jack03";
$statm->bindParam(":username",$username);
$password = "678";
$statm->bindParam(":password",$password);
//执行
$result = $statm->execute();
var_dump($result);


















