<?php 
header("Content-Type:text/html;charset=utf-8");
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
$query = "delete from cms_user where id=?";
$statm = $pdo->prepare($query);
//绑定参数
$id = $_GET['id'];
$statm->bindParam(1,$id);
//执行
$result = $statm->execute();
if($result){
	echo "被影响行数".$statm->rowCount();
}else{
	echo "删除失败";
}













