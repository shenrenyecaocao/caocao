<?php 
header("Content-Type:text/html;charset=utf-8");
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
/*
 * 6、应用PDO准备语句，查询数据库表cms_user中的
* 用户id和用户名，   按行输出每个用户的记录。
*/
$query = "select id,username from cms_user";
$statm = $pdo->prepare($query);
//PDO通知mysql执行sql语句
$statm->execute();
while($row=$statm->fetch(PDO::FETCH_ASSOC)){
	echo "id:".$row['id']."##username:".$row['username']."<br/>";
}
//7、返回上一题中被影响的行数。
echo "共".$statm->rowCount()."行";











