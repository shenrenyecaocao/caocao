<?php 
//PDO准备语句
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
//PDO通知mysql编译sql语句
$query = "insert into cms_user
		  (username,password)
		   value
		  ('tom','123') ";
$statm = $pdo->prepare($query);

//PDOStatment类对象通知mysql执行sql语句
$result = $statm->execute();
var_dump($result);























