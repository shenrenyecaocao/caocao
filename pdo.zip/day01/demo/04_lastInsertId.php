<?php 
header("Content-Type:text/html;charset=utf-8");
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
$query = "insert into cms_user
		  (username,password)
		  value
		  ('jack001','123') ";
$pdo->exec($query);
echo "id:".$pdo->lastInsertId();











