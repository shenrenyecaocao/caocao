<?php 
//获取PDOStatement类对象
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
//访问PDO类的成员方法query
$query = "select id,username from cms_user
		  where id<6";
//PDO类的成员方法query返回一个PDOStatement类对象
$statm = $pdo->query($query);

foreach($statm as $value){
	var_dump($value);//$value是查询的结果。
	                 //关联数组和索引数组
}









