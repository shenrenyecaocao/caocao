<?php 
/*
 * 
2、应用PDO类的query成员方法，查询cms_user表，、
将查询的结果以行的形式输出。即一行输出格式为
   echo 查询的内容 <br/>
 */
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
$query = "select id,username from cms_user
		  where id<10";
$statm = $pdo->query($query);
foreach($statm as $value){
	echo "id:".$value["id"]."username:".$value["username"]."<br/>";
}












