<?php 
header("Content-Type:text/html;charset=utf-8");
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
$query = "select id,username from cms_user";
$statm = $pdo->prepare($query);
//执行
$result = $statm->execute();















