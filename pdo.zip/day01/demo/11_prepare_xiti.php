<?php 
//3、应用准备语句，更新cms_user表里的一条数据。观察返回。
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
//PDO通知mysql编译sql语句
/*
 * 4、应用准备语句，更新cms_user表里的一条数据，
 * 将更新条件设为参数，应用参数绑定指定要更新的记录的id值。
 * 观察更新后的结果。
 */
$query = "update cms_user set password='555' where id=?";
$statm = $pdo->prepare($query);

//绑定参数
$id = 66;
$statm->bindParam(1,$id);

//执行
$result = $statm->execute();

var_dump($result);
















































