<?php 
header("Content-Type:text/html;charset=utf-8");
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
$query = "select id,username from cms_user";
$statm = $pdo->prepare($query);
//执行
$result = $statm->execute();
/*
 * 6、应用PDO准备语句，查询数据库表cms_user中的
 * 用户id和用户名，   按行输出每个用户的记录。

 */
//获取查询的结果
var_dump($statm->fetch(PDO::FETCH_BOTH)); //关联和索引数组

var_dump($statm->fetch(PDO::FETCH_ASSOC));//关联数组

var_dump($statm->fetch(PDO::FETCH_NUM));//索引数组

var_dump($statm->fetch());//false












