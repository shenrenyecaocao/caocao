<?php 
header("Content-Type:text/html;charset=utf-8");
//1、 应用PDO类，删除出cms_user表里的一条记录。观察被影响行数。
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";
$pdo = new PDO($dsn,$username,$password);
$query = "delete from cms_user where id=61";
$affected_rows = $pdo->exec($query);
echo "被影响的行数".$affected_rows;