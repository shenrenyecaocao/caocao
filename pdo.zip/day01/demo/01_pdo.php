<?php 
//获取PDO类的类对象
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";		
$pdo = new PDO($dsn,$username,$password);
var_dump($pdo);