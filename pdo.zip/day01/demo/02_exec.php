<?php 
//获取PDO类的类对象
$dsn = "mysql:host=localhost;dbname=cms";
$username = "root";
$password = "root";		
$pdo = new PDO($dsn,$username,$password);
//执行成员方法exec
/*$query = "insert into cms_user
		  (username,password)
		  values
		  ('rose102','123')";*/
$query = "update cms_user set username='rose103'
		  where id=61";

$affected_rows = $pdo->exec($query);
var_dump($affected_rows);






















