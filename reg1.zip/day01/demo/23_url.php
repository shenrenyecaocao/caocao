<?php 
//7、匹配url地址。
//ftps://www.baidu.com
//ftp http ftps https 协议
//www 主机名称
//baidu 域名
//com 顶级域名
$subject = "ftps://www.baidu.com";
$pattern = "/^(ftps?|https?):\/\/\w+\.[a-z0-9]+\.(com|cn|net|org)$/i";
preg_match_all($pattern,$subject,$match);
var_dump($match);














