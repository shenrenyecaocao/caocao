<?php 
//字符串的分割
/*
 * 8、有如下的字符串：
    this is a test
   对这个字符串，用字母s进行分割。
 */
$subject = "this is a test";
$delimiter = "";
$result = explode($delimiter,$subject,2);
var_dump($result);