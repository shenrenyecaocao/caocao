<?php 
//元字符应用举例
$subject = "this is an island";
//正则表达式
$pattern = "/is\B/";
preg_match_all($pattern,$subject,$match);
var_dump($match);