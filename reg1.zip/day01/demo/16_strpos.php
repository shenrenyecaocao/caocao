<?php 
$haystack = "this is a test";
$needle = "i"; 
/*
 * 2、写一个自定义函数。给一个地址。返回地址中的文件名称。
    例如地址：
    $url = "http://www.baidu.com/index.php".
         文件名称:index.php
    $url = "../image/a.jpg" 文件名称：a.jpg
 */
//echo strpos($haystack,$needle); //2
echo strrpos($haystack,$needle); //5