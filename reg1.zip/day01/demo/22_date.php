<?php 
/*
 * 6、匹配年月日， 格式要求如下：
YYYY-MM-DD或者YYYY/MM/DD 
都视为合法日期。写正则表达式匹配上面的日期。
*/
$subject = "2016/11-11";
$pattern = "/^\d{4}([\-\/])\d{2}\\1\d{2}$/";
preg_match($pattern,$subject,$match);
var_dump($match);














