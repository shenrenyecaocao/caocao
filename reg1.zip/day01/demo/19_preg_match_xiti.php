<?php 
/*
 * 3、应用preg_match，找到字符串
    this is a test中出现的空白。打印出查找的结果。
 */
$subject = "this is a test";
$pattern = "/\s/";
preg_match($pattern,$subject,$match);
var_dump($match);