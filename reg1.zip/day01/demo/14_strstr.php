<?php 
$haystack = "this is a test";
$needle = "is";
echo strstr($haystack,$needle);