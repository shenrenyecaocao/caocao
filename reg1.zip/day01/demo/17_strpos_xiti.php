<?php 
/*
 * 2、写一个自定义函数。给一个地址。返回地址中的文件名称。
    例如地址：
    $url = "http://www.baidu.com/index.php".文件名称:index.php
    $url = "../image/a.jpg" 文件名称：a.jpg
 */
$url = "http://www.baidu.com/index.php";
$url = "../image/a.jpg";
echo getFileName($url);
function getFileName($url){
	//获取最后一次斜线出现的位置
	$pos = strrpos($url,"/");
	//获取文件名称
	$filename = substr($url,$pos+1);
	return $filename;
}











