<?php
header("Content-Type:text/html;charset=utf-8");
include "./functions.inc.php";
//连接数据库
mysql_connect("localhost","root","root");
//选择默认数据库
mysql_select_db("psd1609");
if($_POST){
	$username = $_POST["username"];
	//邮箱地址不能为空
	if($username==""){
		echo "用户名不能为空";
		exit;
	}
	//对用户名即邮箱地址合法性进行验证
	if(!isEmail($username)){
		echo "邮箱地址不合法";
		exit;
	}
	
	$birthday = $_POST["birthday"];
	//邮箱地址不能为空
	if($birthday==""){
		echo "出生日期不能为空";
		exit;
	}
	//对出生日期格式进行验证
	if(!isDate($birthday)){
		echo "出生日期格式不合法";
		exit;
	}
	//收取密码
	$password = $_POST["password"];
	//验证密码不能为空
	if($password==""){
		echo "密码不能为空";
		exit;
	}
	
	//将数据存入到数据库
	$query = "insert user_reg(username,password,birthday)
			  value
			  ('".$username."','".md5($password)."','".$birthday."')";
	$result = mysql_query($query);
	if($result){
		echo "注册成功";
	}else{
		echo "注册失败";
	}
	
	
}
?>
<center>用户注册</center><br/><br/>
<form action="" method="post">
用户名：<input type="text" name="username" /><br/><br/>
出生日期：<input type="text" name="birthday" /><br/><br/>
密&nbsp;&nbsp;&nbsp;码：<input type="password" name="password" /><br/><br/>
<input type="submit" value="注册" />
</form>

 