<?php 
//原子应用举例
$subject = "t3hi5/s i8s a te*st";
//正则表达式
//$pattern = "/[a-z]/"; //代表26个小写英文字母 
//$pattern = "/[A-Z]/"; //代表26个大写英文字母
$pattern = "/[A-Za-z]/"; //代表26个英文字母包括大写和小写
$pattern = "/[0-9]/"; //代表了所有的数字
$pattern = "/[tia]/"; //代表了所有的数字
$pattern = "/[^tia]/"; //^在自定义原子表中代表 非
preg_match_all($pattern,$subject,$match);
var_dump($match);