<?php 
//字符串的分割
$subject = "t4hi6s i8s a te2st";
$pattern = "/\d/";
$result = preg_split($pattern,$subject);
var_dump($result);










