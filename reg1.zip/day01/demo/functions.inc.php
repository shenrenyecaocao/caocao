<?php 
header("Content-Type:text/html;charset=utf-8");
//项目中公用的函数
//验证邮箱地址的合法性

function isEmail($subject){
	//$subject = "tom.service@qq.com"
	//判断$subject是否是一个合法的邮箱地址
	//若subject是一个合法的邮箱地址，返回true 否则 返回 false
	$pattern = "/^\w+([\.\-]?\w+)?@\w+\.(com|cn|net|org)$/i";
	$result = preg_match($pattern,$subject);
	if($result){
		//echo "yes";
		return true;
	}else{
		//echo "no";
		return false;
	}
}

//对出生日期格式进行验证
function isDate($subject){
	//$subject = "2016-11-11"
	//$subject = "2016/11/11"
	$pattern = "/^\d{4}([\-\/])\d{2}\\1\d{2}$/";
	$result = preg_match($pattern,$subject);
	if($result){
		return true;
	}else{
		return false;
	}
}
























