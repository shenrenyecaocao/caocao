<?php 
//5、匹配邮箱
$subject = "tom-service@qq.cn";//tom@163.com //tom@z.com
//$subject = "tom@qq.cn";
$pattern = "/^\w+([\.\-]?\w+)?@\w+\.(com|cn|org|net)$/i";
preg_match_all($pattern,$subject,$match);
var_dump($match);
