<?php 
/*1、应用正则表达式函数preg_match_all。匹配出字符串中
 * 的所有数字
th3is i6s a te90st
将匹配到的结果打印出来。*/
$subject = "th3is i6s a te90st";
$pattern = "/\d/";
$pattern = "/[0-9]/";
preg_match_all($pattern,$subject,$match);
var_dump($match);