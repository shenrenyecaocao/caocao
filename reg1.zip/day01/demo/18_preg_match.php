<?php 
/*
 * 3、应用preg_match，找到字符串
    this is a test中出现的空白。打印出查找的结果。
 */

$subject = "this is a test";
$pattern = "/t/";
//var_dump(preg_match_all($pattern,$subject,$match));//3
var_dump(preg_match($pattern,$subject,$match));
echo "<hr/>";
var_dump($match);//匹配到3次结果