<?php 
$input = array("tom@qq.com","tom.service@163.com",
		       "tom#service@hotmail.com");
$pattern = "/^\w+([\.\-]\w+)?@\w+\.(com|cn|net|org)$/i";
$result = preg_grep($pattern,$input);
var_dump($result);













