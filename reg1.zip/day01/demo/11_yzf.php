<?php 
//元字符应用举例
$subject = "mysqoracle";
//正则表达式
$pattern = "/mysq(l|o)racle/";
preg_match_all($pattern,$subject,$match);
var_dump($match);