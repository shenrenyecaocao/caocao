<?php 
$str = "this is a test";
echo substr($str,5,2);
