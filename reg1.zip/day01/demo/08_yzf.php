<?php 
//元字符应用举例
$subject = "this is a tesabct";
//正则表达式
//$pattern = "/\Aabc/";//^以原子作为字符串的开始
//$pattern = "/abc$/";//$以原子作为字符串的结尾
$pattern = "/abc\Z/";//$以原子作为字符串的结尾
preg_match_all($pattern,$subject,$match);
var_dump($match);