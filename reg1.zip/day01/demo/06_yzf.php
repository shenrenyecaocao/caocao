<?php 
//元字符应用举例
$subject = "gogle";
//正则表达式
//$pattern = "/go{2}gle/";//{n}代表被修饰的原子要出现n次（2次）
//$pattern = "/go{2,5}gle/";//{n,m}代表被修饰的原子要出现n到m次。
$pattern = "/go{2,}gle/";//{n,}代表被修饰的原子最少出现n次，最多不限制


preg_match_all($pattern,$subject,$match);
var_dump($match);