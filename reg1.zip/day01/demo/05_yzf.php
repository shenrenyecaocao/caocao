<?php 
//元字符应用举例
$subject = "ggle";
//正则表达式
//$pattern = "/go*gle/";//*代表被修饰的原子可以出现0次到多次
//$pattern = "/go+gle/";//+代表被修饰的原子可以出现1次到多次
$pattern = "/go?gle/";//?代表被修饰的原子可以出现0次到1次
preg_match_all($pattern,$subject,$match);
var_dump($match);