<?php 
//4、应用正则匹配手机号码

$subject = "15831092076";//1 34578
$pattern = "/^1[34578]\d{9}$/";
preg_match($pattern,$subject,$match);
var_dump($match);
