<?php 
//原子应用举例
$subject = "t3hi5/s i8s a te*st";
//正则表达式
$pattern = "/./"; //代表26个小写英文字母 

preg_match_all($pattern,$subject,$match);
var_dump($match);