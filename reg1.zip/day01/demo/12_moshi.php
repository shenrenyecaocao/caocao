<?php 
//模式修正符应用举例
$subject = "this is a test";
//正则表达式
$pattern = "/TEST/i"; //i 修正正则表达式忽略掉大小写
preg_match_all($pattern,$subject,$match);
var_dump($match);