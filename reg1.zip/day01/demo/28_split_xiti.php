<?php 
//字符串的分割
/*
 * 9、对字符串进行分割，要求用所有的标点符号进行分割
    th,i\.s i;s a t!e?st
 */
$subject = "th,i.s i;s a t!e?st";
$pattern = "/[,\.;!\?]/";
$result = preg_split($pattern,$subject);
var_dump($result);









