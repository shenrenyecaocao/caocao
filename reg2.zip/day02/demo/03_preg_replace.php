<?php
header("Content-Type:text/html;charset=utf-8"); 
$subject = "this is a test";
//正则表达式
$pattern = "/t/";
$replace = "w";
echo preg_replace($pattern,$replace,$subject);









