<?php
header("Content-Type:text/html;charset=utf-8");
//替换掉字符串中的HTML标签 
$subject = "abchttp://www.baidu.comabchttps://www.yahoo.comabcftp://image.sohu.comabcftps://www.163.comabc";
//echo $subject;
//正则表达式
$pattern ="/(https?|ftps?):\/\/(\w+)\.(\w+)\.(com|cn|org|net)/";
/*$pattern ="/(https?|ftps?):\/\/(\w+)\.(\w+)\.(com|cn|org|net)/";
preg_match_all($pattern,$subject,$match);

var_dump($match);*/
//利用反向引用
//URL地址
$replace = "<a href='\\1://\\2.\\3.\\4'>\\1://\\2.\\3.\\4</a>";
echo "<hr/>";
echo preg_replace($pattern,$replace,$subject);









