<?php
header("Content-Type:text/html;charset=utf-8"); 
/*
 * 1、将下列字符串进行查找替换：
   今天的晚饭是：米饭、馒头、面条
   将今天的晚饭替换成你爱吃的。
 */
//字符串的替换
$subject = "今天的晚饭是：米饭、馒头、面条";
$search = array("米饭","馒头","面条");
$replace = array("饺子","包子","米线");
echo str_replace($search,$replace,$subject);










