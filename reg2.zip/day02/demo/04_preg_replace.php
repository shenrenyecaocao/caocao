<?php
header("Content-Type:text/html;charset=utf-8");
//替换掉字符串中的HTML标签 
$subject = "我是一个含有<span style='color:red;'>HTML</span>
		      标签的<strong>字符</strong>串";
//正则表达式，匹配HTML标签
$pattern = "/<[\w\s=':;\"\-\#\/]+>/";
//$pattern = "/<[^<>]+>/";
$replace = "";
echo preg_replace($pattern,$replace,$subject);









